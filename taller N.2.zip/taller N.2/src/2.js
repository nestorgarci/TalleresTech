// Parte 1: Declaración de Variables y Tipos de Datos
function mostrarVariables() {
    let nombre = document.getElementById("nombre").value;
    let edad = parseInt(document.getElementById("edad").value);
    let esEstudiante = document.getElementById("esEstudiante").value === "true";

    let resultado = `Nombre: ${nombre}, Edad: ${edad}, ¿Es estudiante?: ${esEstudiante}`;
    document.getElementById("resultadoVariables").innerText = resultado;
}

// Parte 2: Operaciones Matemáticas y Comparación
function realizarOperaciones() {
    let a = parseFloat(document.getElementById("numeroA").value);
    let b = parseFloat(document.getElementById("numeroB").value);

    let suma = a + b;
    let resta = a - b;
    let multiplicacion = a * b;
    let division = a / b;

    let comparaciones = `
        Suma: ${suma}
        Resta: ${resta}
        Multiplicación: ${multiplicacion}
        División: ${division}
        ¿A es igual a B?: ${a === b}
        ¿A no es igual a B?: ${a !== b}
        ¿A es mayor que B?: ${a > b}
        ¿A es menor que B?: ${a < b}
        ¿A es mayor o igual a B?: ${a >= b}
        ¿A es menor o igual a B?: ${a <= b}
    `;

    document.getElementById("resultadoOperaciones").innerText = comparaciones;
}

// Parte 3: Operadores Lógicos y Concatenación de Strings
function verificarConduccion() {
    let esMayorDeEdad = document.getElementById("esMayorDeEdad").value === "true";
    let tieneLicencia = document.getElementById("tieneLicencia").value === "true";

    let puedeConducir = esMayorDeEdad && tieneLicencia;
    let resultadoConduccion = puedeConducir 
        ? "La persona puede conducir." 
        : "La persona NO puede conducir.";

    let saludo = `Hola, ${document.getElementById("nombre").value}. Bienvenido a nuestro sitio.`;

    document.getElementById("resultadoConduccion").innerText = `${resultadoConduccion} ${saludo}`;
}
